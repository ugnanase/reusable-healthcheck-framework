package CBSServicesV1_0;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.print.DocFlavor.INPUT_STREAM;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;


public class MF_CBSServicesTest_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");
		ArrayList<String> lServiceNameList = new ArrayList<>();
		ArrayList<String> lStatusList = new ArrayList<>();
		ArrayList<String> lOperationList = new ArrayList<>();
		ArrayList<String> lReqTimeList = new ArrayList<>();
		ArrayList<String> lResTimeList = new ArrayList<>();

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = inAssembly;
		try {
			
			
			Process p1= Runtime.getRuntime().exec("mqsireportproperties CANDEVBRK1 -b agent -o ComIbmJVMManager -n jvmMaxHeapSize");
			InputStream is1=p1.getInputStream();
			InputStreamReader isr1=new InputStreamReader(is1);
			BufferedReader br1=new BufferedReader(isr1);
			Process p2= Runtime.getRuntime().exec("mqsireportproperties CANDEVBRK1 -b agent -o ComIbmJVMManager -n jvmMinHeapSize");
			InputStream is2=p2.getInputStream();
			InputStreamReader isr2=new InputStreamReader(is2);
			BufferedReader br2=new BufferedReader(isr2);
			Process p3= Runtime.getRuntime().exec("mqsilist");
			InputStream is3=p3.getInputStream();
			InputStreamReader isr3=new InputStreamReader(is3);
			BufferedReader br3=new BufferedReader(isr3);
			String heartBeat;
			String heartBeatStatus="In-Active";
			while((heartBeat = br3.readLine()) != null)
			{
				if(heartBeat.contains("CANDEVBRK1") & heartBeat.contains("running"))
				{
					heartBeatStatus="Active";
				}
			}
			String maxHeapSize,minHeapSize;
			maxHeapSize=br1.readLine();
			minHeapSize=br2.readLine();
			while((maxHeapSize = br1.readLine()) != null)
			{
				System.out.println("maxHeapSize:"+maxHeapSize);
				break;
			}
			while((minHeapSize = br2.readLine()) != null)
			{
				System.out.println("minHeapSize:"+minHeapSize);
				break;
			}
			File file=new File("C:\\Workout\\LogFile\\ESB_Log.log");
			String fileSize=file.length()+"byes";
			
			
			MbElement outRoot = inMessage.getRootElement();
			MbElement outputBody = outRoot.getLastChild();
			MbElement xmlInput = outputBody.getFirstChild();
			
			for (MbElement item: (List<MbElement>) outputBody.evaluateXPath("./CBSApplicationResponse/Service"))
	          {
	            MbElement cursor = item.getFirstElementByPath("ServiceName");
	            String lServiceName = cursor.getValue().toString();
	            lServiceNameList.add(lServiceName);
	            cursor = cursor.getNextSibling(); 
	            
	            String lOperation = cursor.getValue().toString();
	            lOperationList.add(lOperation);
	            cursor = cursor.getNextSibling(); 
	            
	            String lStatus = cursor.getValue().toString();
	            lStatusList.add(lStatus);
	            cursor = cursor.getNextSibling(); 
	            
	            String lReqTime= cursor.getValue().toString();
	            lReqTimeList.add(lReqTime);
	            cursor = cursor.getNextSibling(); 
	            
	            String lResTime = cursor.getValue().toString();
	            lResTimeList.add(lResTime);
	           } 
			
			Workbook workbook = new HSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

			Sheet sheet = workbook.createSheet("Status");
	        
	     // Create a Font for styling header cells
	        Font headerFont = workbook.createFont();
	        headerFont.setBold(true);
	        headerFont.setFontHeightInPoints((short) 14);
	        //headerFont.setColor(IndexedColors.BLUE.getIndex());

	        // Create a CellStyle with the font
	        CellStyle headerCellStyle = workbook.createCellStyle();
	        headerCellStyle.setFont(headerFont);
	        
	        CellStyle DateCellStyle = workbook.createCellStyle();
	        CreationHelper createHelp=workbook.getCreationHelper();
	        DateCellStyle.setDataFormat(createHelp.createDataFormat().getFormat("m/d/yy h:mm"));
	       
	        //Server Info Details
	        Row headerRowS = sheet.createRow(0);
	        Cell cell0 = headerRowS.createCell(0);
	        cell0.setCellValue("Server Info");
	        cell0.setCellStyle(headerCellStyle);
	        
	        Row headerRow0 = sheet.createRow(1);
	        cell0 = headerRow0.createCell(1);
	        cell0.setCellValue("Log File Size");
	        cell0.setCellStyle(headerCellStyle);
	        
	        cell0 = headerRow0.createCell(2);
	        cell0.setCellValue("Log Location");
	        cell0.setCellStyle(headerCellStyle);
	        
	        cell0 = headerRow0.createCell(3);
	        cell0.setCellValue("Minimum Heap Size");
	        cell0.setCellStyle(headerCellStyle);
	        
	        cell0 = headerRow0.createCell(4);
	        cell0.setCellValue("Maximum Heap Size");
	        cell0.setCellStyle(headerCellStyle);
	        
	        cell0 = headerRow0.createCell(5);
	        cell0.setCellValue("Broker Heart Beat");
	        cell0.setCellStyle(headerCellStyle);
	        
	        Row dataRow0 = null;
	       
	       
	       
	        	dataRow0 = sheet.createRow(2);
	        	cell0 = dataRow0.createCell(0);
	        	cell0.setCellValue("");
	        	cell0 = dataRow0.createCell(1);
	        	cell0.setCellValue(fileSize);
	        	cell0 = dataRow0.createCell(2);
	        	cell0.setCellValue("C:\\Workout\\LogFile\\ESB_Log.log");
	        	cell0 = dataRow0.createCell(3);
	        	cell0.setCellValue(minHeapSize);
	        	cell0 = dataRow0.createCell(4);
	        	cell0.setCellValue(maxHeapSize);
	        	cell0 = dataRow0.createCell(5);
	        	cell0.setCellValue(heartBeatStatus);
	        
	     
	        // Create a Row
	        Row headerRow = sheet.createRow(4);
	        
	        Cell cell = headerRow.createCell(0);
	        cell.setCellValue("SL No");
	        cell.setCellStyle(headerCellStyle);
	        
	        cell = headerRow.createCell(1);
	        cell.setCellValue("Service Name");
	        cell.setCellStyle(headerCellStyle);
	       
	        cell = headerRow.createCell(2);
	        cell.setCellValue("Operation Name");
	        cell.setCellStyle(headerCellStyle);
	       
	        
	        cell = headerRow.createCell(3);
	        cell.setCellValue("Status");
	        cell.setCellStyle(headerCellStyle);
	        
	        cell = headerRow.createCell(4);
	        cell.setCellValue("RequestTime");
	        cell.setCellStyle(headerCellStyle);
	        
	        cell = headerRow.createCell(5);
	        cell.setCellValue("ResponseTime");
	        cell.setCellStyle(headerCellStyle);
	        
	        
	        Row dataRow = null;
	        int rowNum = 5;
	        
	    
	       
	        for(int i = 0;i < lServiceNameList.size();i++)
	        {
	        	dataRow = sheet.createRow(rowNum);
	        	rowNum++;
	        	cell = dataRow.createCell(0);
	        	cell.setCellValue(i+1);
	        	cell = dataRow.createCell(1);
	        	cell.setCellValue(lServiceNameList.get(i));
	        	cell = dataRow.createCell(2);
	        	cell.setCellValue(lOperationList.get(i));
	        	cell = dataRow.createCell(3);
	        	cell.setCellValue(lStatusList.get(i));
	        	cell = dataRow.createCell(4);
	        	cell.setCellValue(lReqTimeList.get(i));
	        	cell = dataRow.createCell(5);
	        	cell.setCellValue(lResTimeList.get(i));
	        }
	        FileOutputStream fileOut = new FileOutputStream("c:\\Workout\\LogFile\\CBS_SERVICES_FINAL_RESP_XL\\CBS_Final_Resp.xls");
	        
	        workbook.write(fileOut);
	        fileOut.close();

	        // Closing the workbook
	        workbook.close();
	      
			// create new message as a copy of the input
			
			// ----------------------------------------------------------
			// Add user code below

			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}
}
